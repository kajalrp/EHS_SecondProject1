﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using LoginInMVC4WithEF.Models;


namespace LoginInMVC4WithEF.Controllers
{
    public class UserController : Controller
    {
        //
        // GET: /User/
        public ActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public ActionResult LogIn()
        {
            return View();
        }
        [HttpPost]
        public ActionResult LogIn(Models.Seller seller)
        {
            //if (ModelState.IsValid)
            //{
                if (IsValid(seller.UserName, seller.Password))
                {
                    FormsAuthentication.SetAuthCookie(seller.UserName, false);
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    ModelState.AddModelError("", "Login details are wrong.");
                }
            //}
            //else
            //{
            //    ModelState.AddModelError("", "Error, Check data");
            //}
            return View(seller);
        }

        [HttpGet]
        public ActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Register(Models.Seller user)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    using (var db = new LoginInMVC4WithEF.Models.Training_24Oct18_PuneEntities())
                    {
                        var crypto = new SimpleCrypto.PBKDF2();
                 //       var encrypPass = crypto.Compute(user.Password);
                        var newUser = db.Sellers.Create();

                        newUser.UserName = user.UserName;
                        newUser.FirstName = user.FirstName;
                        newUser.LastName = user.LastName;
                        newUser.DateofBirth = user.DateofBirth;
                        newUser.PhoneNo = user.PhoneNo;
                        newUser.Address = user.Address;
                        newUser.StateId = user.StateId;
                        newUser.CityId = user.CityId;
                        newUser.EmailId = user.EmailId;
                        //   newUser.Password = encrypPass;
                        newUser.Password = user.Password;
                    
                     
                        db.Sellers.Add(newUser);
                        db.SaveChanges();
                        return RedirectToAction("Index", "Home");
                    }
                }
                else
                {
                    ModelState.AddModelError("", "Data is not correct");
                }
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }

            return View();
        }

        public ActionResult LogOut()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Index", "Home");
        }

        private bool IsValid(string email, string password)
        {
            var crypto = new SimpleCrypto.PBKDF2();
            bool IsValid = false;

            using (var db = new LoginInMVC4WithEF.Models.Training_24Oct18_PuneEntities())
            {
                var user = db.Sellers.FirstOrDefault(u => u.EmailId == email);
                if (user != null)
                {
                    if (user.Password == crypto.Compute(password, user.Password))
                    {
                        IsValid = true;
                    }
                }
            }
            return IsValid;
        }

    }
}
